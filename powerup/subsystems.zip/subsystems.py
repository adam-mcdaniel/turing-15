import wpilib
import ctre
import sensors
import controls
from networktables import NetworkTables
import logging
import math
import pathfinder as pf
# from pathfinder.followers import EncoderFollower

# DASHBOARD #
dashboard = NetworkTables.getTable("SmartDashboard")
logger = logging.getLogger("robot")


# DRIVE TRAIN #
leftFrontMotor = sensors.DriveMotor(1)
leftFrontMotor.invert()
leftCenterMotor = sensors.FollowMotor(3, leftFrontMotor)
leftRearMotor = sensors.DriveMotor(2)


rightFrontMotor = sensors.DriveMotor(4)
rightCenterMotor = sensors.FollowMotor(5, rightFrontMotor)
rightRearMotor = sensors.DriveMotor(6)

# leftFrontMotor = ctre.wpi_talonsrx.WPI_TalonSRX(1)
# leftRearMotor = ctre.wpi_talonsrx.WPI_TalonSRX(2)
# rightFrontMotor = ctre.wpi_talonsrx.WPI_TalonSRX(3)
# rightRearMotor = ctre.wpi_talonsrx.WPI_TalonSRX(4)
carriageLift = sensors.DriveMotor(7)

# INTAKE #
leftIntakeMotor = ctre.wpi_talonsrx.WPI_TalonSRX(8)
rightIntakeMotor = ctre.wpi_talonsrx.WPI_TalonSRX(9)
leftIntakeMotor.setInverted(True)
# rightIntakeMotor.setInverted(True)

compressor = wpilib.Compressor()

# SENSORS #
gyro = sensors.Gyro(scale_factor=6.744578313253012)
ultrasonic_sensor = sensors.UltraSonicSensor(2)

# PATHFINDING #


class PathFinder():
    WHEEL_DIAMETER = 0.5  # 6 inches
    ENCODER_COUNTS_PER_REV = 4096

    # Pathfinder constants
    MAX_VELOCITY = 11  # ft/s
    MAX_ACCELERATION = 1

    WHEEL_BASE = (29/12)

    def __init__(self, points, period, gyro, left_motor, right_motor):
        self.gyro = gyro
        self.l_motor = left_motor
        self.r_motor = right_motor

        # self.r_motor.invert()
        self.reset()

        info, trajectory = pf.generate(points, pf.FIT_HERMITE_CUBIC, pf.SAMPLES_HIGH,
                                       dt=period,
                                       max_velocity=self.MAX_VELOCITY,
                                       max_acceleration=self.MAX_ACCELERATION,
                                       max_jerk=120.0)

        # Wheelbase Width = 2 ft
        modifier = pf.modifiers.TankModifier(trajectory).modify(self.WHEEL_BASE)

        # Do something with the new Trajectories...
        left = modifier.getLeftTrajectory()
        right = modifier.getRightTrajectory()

        leftFollower = pf.followers.EncoderFollower(left)
        leftFollower.configureEncoder(
            self.l_motor.getRawPosition(), 4096, self.WHEEL_DIAMETER)
        leftFollower.configurePIDVA(1.0, 0.0, 0, 1 / self.MAX_VELOCITY, 0)
        leftFollower.segment = 0

        rightFollower = pf.followers.EncoderFollower(right)
        rightFollower.configureEncoder(
            self.r_motor.getRawPosition(), 4096, self.WHEEL_DIAMETER)
        rightFollower.configurePIDVA(1.0, 0.0, 0, 1 / self.MAX_VELOCITY, 0)
        rightFollower.segment = 0

        self.leftFollower = leftFollower
        self.rightFollower = rightFollower

    def reset(self):
        self.l_motor.resetPostion()
        self.r_motor.resetPostion()
        self.gyro.reset()

    def calculate(self):
        lvel = self.leftFollower.calculate(
            self.l_motor.getRawPosition())
        rvel = self.rightFollower.calculate(
            self.l_motor.getRawPosition())

        print("l: {}".format(self.l_motor.getRawPosition()))
        print("r: {}".format(self.r_motor.getRawPosition()))

        gyro_heading = -self.gyro.getAngle()

        desired_heading = pf.r2d(self.leftFollower.getHeading())

        angleDifference = pf.boundHalfDegrees(desired_heading - gyro_heading)
        turn = 0.8 * (-1.0 / 80.0) * angleDifference

        lvel = lvel + turn
        rvel = rvel - turn
        # -1 is forward, so invert both values
        return -lvel, -rvel


class ChassisPIDs(wpilib.RobotDrive):
    def __init__(self, lfm, lbm, rfm, rbm):
        super().__init__(lfm, lbm, rfm, rbm)
        self.gyroPID = wpilib.PIDController(0.1,
                                            0,
                                            0,
                                            gyro.getAngle,
                                            # (lambda a: logger.log(0, msg="GyroPID Output: " + str(a))))
                                            (lambda a: None))

        self.gyroPID.enable()
        self.cubeTrackPID = wpilib.PIDController(0.1,
                                                 0,
                                                 0,
                                                 gyro.getAngle,
                                                 # (lambda a: logger.log(0, msg="CubeTrackingPID Output: " + str(a))))
                                                 (lambda a: None))
        self.cubeTrackPID.enable()

        self.motors = [
            leftFrontMotor,
            leftRearMotor,
            rightFrontMotor,
            rightRearMotor,
        ]

        self.left_motors = [
            leftFrontMotor,
            leftRearMotor
        ]

        self.right_motors = [
            rightFrontMotor,
            rightRearMotor
        ]

        list(map(lambda a: a.resetPostion(), self.motors))

    def goToAngle(self, angle):
        self.gyroPID.setSetpoint(angle)
        for i in range(0, 50):
            wpilib.timer.Timer.delay(1 / 50)
            self.arcadeDrive(0, self.gyroPID.get())
            dashboard.putNumber("Gyro",
                                gyro.getAngle())


class Chassis(ChassisPIDs):
    # def __init__(self, lfm, lbm, rfm, rbm):
    def __init__(self, lfm, lbm, rfm, rbm):
        super().__init__(lfm, lbm, rfm, rbm)
        self.shifter = wpilib.DoubleSolenoid(20, 0, 1)
        self.currentGear = "Extended"

    def update(self, joystick, buttons):
        # dashboard.putNumber("LeftFrontCurrent",
        #                     leftFrontMotor.getOutputCurrent())
        # dashboard.putNumber("LeftCenterCurrent",
        #                     leftCenterMotor.getOutputCurrent())
        # dashboard.putNumber("LeftRearCurrent",
        #                     leftRearMotor.getOutputCurrent())
        # dashboard.putNumber("RightFrontCurrent",
        #                     rightFrontMotor.getOutputCurrent())
        # dashboard.putNumber("RightCenterCurrent",
        #                     rightCenterMotor.getOutputCurrent())
        # dashboard.putNumber("RightRearCurrent",
        #                     rightRearMotor.getOutputCurrent())

        dashboard.putNumber("RightFrontPosition",
                            rightFrontMotor.getPosition())
        dashboard.putNumber("LeftFrontPosition",
                            leftFrontMotor.getPosition())
        dashboard.putNumber("Gyro",
                            gyro.getAngle())

        self.arcadeDrive(joystick.getY(), joystick.getRawAxis(2) * 0.8)
        # self.arcadeDrive(joystick.getY(), joystick.getRawAxis(4) * 0.8)
        self.arcadeDrive(joystick.getRawAxis(
            controls.joystick["forward-axis"]), joystick.getRawAxis(controls.joystick["turn-axis"]) * 0.8)
        if joystick.getRawButton(controls.joystick["shift"]):
            self.shift()
        if joystick.getRawButton(controls.joystick["goto 0"]):
            self.goToAngle(0)

    def shift(self):
        self.arcadeDrive(0, 0)
        wpilib.timer.Timer.delay(0.2)
        if self.currentGear == "Extended":
            self.currentGear = "Retracted"
            self.shifter.set(wpilib.DoubleSolenoid.Value.kReverse)
        elif self.currentGear == "Retracted":
            self.currentGear = "Extended"
            # self.shifter.set(wpilib.DoubleSolenoid.Value.kForward) No high gear allowed.
            self.shifter.set(wpilib.DoubleSolenoid.Value.kReverse)

    def getLeftPosition(self):
        return leftFrontMotor.getRawPosition()

    def getRightPosition(self):
        return rightFrontMotor.getRawPosition()


class Launcher(wpilib.RobotDrive):
    def __init__(self):
        super().__init__(leftIntakeMotor, rightIntakeMotor)
        self.launcherArms = wpilib.DoubleSolenoid(20, 4, 5)
        self.lifterArms = wpilib.DoubleSolenoid(20, 2, 3)
        self.pokeyBoi = wpilib.DoubleSolenoid(10, 6, 7)
        # self.pokeyBoi = wpilib.DoubleSolenoid(20, 0, 1)
        self.lifterArms.set(wpilib.DoubleSolenoid.Value.kReverse)
        self.currentLifted = "Extended"
        self.locked = True
        self.cubeState = False

    def update(self, joystick, buttons):
        if buttons.getRawButton(controls.buttons["launch"]):
            self.launch()
        if joystick.getRawButton(controls.joystick["intake"]):
            self.intake()
        if joystick.getRawButton(controls.joystick["cattywampus"]):
            self.cattywampus()
        if joystick.getRawButton(controls.joystick["outtake"]):
            self.outtake()
            self.cubeState = False
        if buttons.getRawButton(controls.buttons["toggle"]):
            self.toggle()
        if joystick.getRawButton(controls.joystick["launch"]):
            self.launch()
            self.cubeState = False
        if joystick.getRawButton(controls.joystick["toggle"]):
            self.toggle()
            if self.locked:
                wpilib.timer.Timer.delay(0.5)
                self.locked = False
                self.close()
            else:
                self.locked = True
                wpilib.timer.Timer.delay(0.5)

        if buttons.getRawButton(controls.buttons["close"]) or joystick.getRawButton(controls.joystick["close"]) or self.locked:
            self.close()
        else:
            self.open()

        if self.cube():
            dashboard.putNumber("HasCube", 1)
            self.cubeState = True
        else:
            dashboard.putNumber("HasCube", 0)

    def launch(self):
        self.pokeyBoi.set(wpilib.DoubleSolenoid.Value.kForward)
        # wpilib.timer.Timer.delay(dashboard.getNumber("DB/Slider 1", 0))
        self.arcadeDrive(-1, 0)

    def intake(self):
        self.arcadeDrive(0.8, 0)

    def cube(self):
        return leftIntakeMotor.getOutputCurrent() > dashboard.getNumber("DB/Slider 1", 0) and rightIntakeMotor.getOutputCurrent() > dashboard.getNumber("DB/Slider 1", 0)

    def outtake(self):
        self.arcadeDrive(-0.65, 0)

    def cattywampus(self):
        self.arcadeDrive(0, -0.7)

    def toggle(self):
        wpilib.timer.Timer.delay(0.2)
        if self.currentLifted == "Extended":
            self.currentLifted = "Retracted"
            self.lifterArms.set(wpilib.DoubleSolenoid.Value.kReverse)
        elif self.currentLifted == "Retracted":
            self.currentLifted = "Extended"
            self.lifterArms.set(wpilib.DoubleSolenoid.Value.kForward)

    def open(self):
        self.launcherArms.set(wpilib.DoubleSolenoid.Value.kForward)

    def close(self):
        self.launcherArms.set(wpilib.DoubleSolenoid.Value.kReverse)


class Elevator():
    def __init__(self):
        self.carriageLift = carriageLift
        # self.carriageLift.configPeakCurrentLimit(dashboard.getNumber("DB/Slider 1", 0), 10)
        # self.carriageLift.configPeakCurrentDuration(200)
        # self.carriageLift.enableCurrentLimit(True)
        self.state = "Descending"
        self.cycle = 0

    def getPosition(self):
        return self.carriageLift.getPosition()

    def lift(self):
        self.state = "Lifting"

    def descend(self):
        self.state = "Descending"

    def exchange(self):
        self.carriageLift.set(-0.5)
        wpilib.timer.Timer.delay(0.4)
        wpilib.RobotDrive(leftIntakeMotor, rightIntakeMotor).arcadeDrive(-1, 0)
        self.carriageLift.set(0)

    def update(self, joystick, buttons):
        if buttons.getRawButton(controls.buttons["lift"]):
            self.lift()
        elif buttons.getRawButton(controls.buttons["descend"]):
            self.descend()
        if joystick.getRawButton(controls.joystick["lift"]):
            self.lift()
        elif joystick.getRawButton(controls.joystick["descend"]):
            self.descend()
        elif joystick.getRawButton(controls.joystick["exchange"]):
            self.exchange()

        if self.state == "Descending":
            self.carriageLift.set(0)
            self.cycle = 0
        elif self.state == "Lifting":
            if self.cycle < 46 and abs(self.carriageLift.getOutputCurrent()) < 8:
                self.carriageLift.set(-0.5)
                self.cycle += 1
            else:
                self.carriageLift.set(-0.2)

        dashboard.putNumber("Elevator position", self.getPosition())


def HiroChassis():
    return Chassis(leftFrontMotor,
                   # leftCenterMotor,
                   leftRearMotor,
                   rightFrontMotor,
                   # rightCenterMotor,
                   rightRearMotor)


def HiroLauncher():
    return Launcher()


def HiroElevator():
    return Elevator()


def HiroPathfinder(period):
    return PathFinder([
            pf.Waypoint(0, 0, 0),
            pf.Waypoint(9, -5, 0),
        ], period, gyro, leftFrontMotor, rightFrontMotor)


"""
class Best
{
    Best(){}
};

class Deanna : Best
{
public:
    Deanna(){}
};

int main()
{
    Deanna deanna = Best();
}
"""
